/*
SPDX-License-Identifier: Apache-2.0
*/

'use strict';

const cpcontract = require('./lib/trade.js');
module.exports.contracts = [cpcontract];

